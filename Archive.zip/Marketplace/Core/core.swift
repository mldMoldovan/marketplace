//
//  core.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 29/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit


class core{
    
    static let debug = true
    static let logs = true
    static let main = loginController()
    static let color = UIColor.clear
    static let man = aku()
    static var logCounter = 0
    
    static var usr = user("garcea2005", "Garcea Gabriel")
    static var wal = wallet("portofel", currency: .euro, owner: core.usr, code: "1234")
    
    
    static var wallets:[wallet] = []
    static var marketplace:[item] = []
    
    
    static let w = UIScreen.main.bounds.width
    static let h = UIScreen.main.bounds.height
    
    
    
    
}


class aku{
    
    var data:[AnyObject] = []
    
    
    
    // MARK: DATA RETRIEVAL
    
    
    // IMAGES
    
    func img(_ key: String) -> UIImage{
        
        
        print(" ~> AKU >> image load failure at: ", key)
        
        return (_imgs[key] ?? UIImage(named: "retrieve_fail"))!
        
        
    }
    
    
    // STRINGS
    
    
    func str(_ key: String) -> String{
        
        print(" ~> AKU >> string load failure at: ", key)
        
        return _strs[key] ?? "retrieve_fail KEY ~> " + key + " <~ "
        
    }
    
    // CONTROLLERS
    
    func troll(_ key: String) -> XTController{
        
        print(" ~> AKU >> troll load failure at: ", key)
        
        return _ctrs[key] ?? failController()
        
    }
    
    
    // COLORS
    
    
    func color(_ key: String) -> UIColor{
        
        print(" ~> AKU >> color load failure at: ", key)
        
        return _clrs[key] ?? UIColor.red.withAlphaComponent(0.5)
        
    }
    
    
    // MARK: RETURN FROM FILE
    
    
    func returnFromFile(_ file: String?) -> AnyObject? {
      if let path = Bundle.main.path(forResource: "users", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let json = try! JSONSerialization.jsonObject(with: data, options: []) as? [[String:Any]]{
                    return json as AnyObject
                }
            } catch{
                
                print("AKU returnFromFile ERROR")
                
            }
        }
        
        return nil
    }
    
    
    
    // MARK: RETURN FROM SERVER
    
    
    func returnFromServer(_ url: String?) -> AnyObject? {
            if let oo = url{
                if let oorl = URL(string: oo){
                        let rq = URLRequest(url: oorl)
                        let sesh = URLSession.shared
                        let tsk = sesh.dataTask(with: rq, completionHandler: { data, resp, err -> Void in
                            if err == nil{
                                print(data as Any)
                                print(resp as Any)
                                print("AKU ~> $ Data loaded...")
                            } else {
                                print("AKU ~> ! ERROR ", err as Any)
                            }
                            
                        
                        })
                        tsk.resume()
                    
                } else {
                    print("AKU ~> ! URL Failure...")
                    return "Poo" as AnyObject
                }
            } else {
                print("AKU ~> ! No URL...")
                return "Phoo" as AnyObject
        }
        print("AKU ~> ! Pizdec...")
        return nil
        
    }
        
        
    // MARK: PUSH TO FILE
    
    
    func pushToFile(_ file: String?) -> AnyObject? {
        
        
        guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        let fileUrl = documentDirectoryUrl.appendingPathComponent(file! + ".json")

        let whatever =  [["parizer": ["praz": "pateu", "ciucarie": "salvie"]], ["cartof": ["adriaCola": "salam", "soofloo": "saphir"]]]

        do {
            let data = try JSONSerialization.data(withJSONObject: whatever, options: [])
            try data.write(to: fileUrl, options: [])
            print("AKU ~> $ Data written to file...")
        } catch {
            print(error)
        }
        
        return nil
    }
    
    
    // MARK: PUSH TO SERVER
    
    
    
    func pushToServer(_ url: String?) -> AnyObject? {
       if let oo = url{
                if let oorl = URL(string: oo){
                        var rq = URLRequest(url: oorl)
                        rq.httpMethod = "POST"
                        let sesh = URLSession.shared
                        let tsk = sesh.dataTask(with: rq, completionHandler: { data, resp, err -> Void in
                        
                            self.data[0] = data! as AnyObject
                            print("AKU ~> $ Data loaded...")
                        
                        })
                        tsk.resume()
                    
                } else {
                    print("AKU ~> ! URL Failure...")
                    return "Poo" as AnyObject
                }
            } else {
                print("AKU ~> ! No URL...")
                return "Phoo" as AnyObject
        }
        print("AKU ~> ! Pizdec... >> ", url ?? "url retrievalFailure")
        return nil
    }

    
    
}
