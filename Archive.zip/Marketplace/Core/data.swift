//
//  _imgs.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 29/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit



// MARK: IMAGES

let _imgs : [String:UIImage?] = [

    
    "eur" : UIImage(named: "eur_icon"),
    "btc" : UIImage(named: "btc_icon"),
    "usd" : UIImage(named: "usd_icon"),
    
    
    "bkg" : UIImage(named: "background"),
    "login_bkg" : UIImage(named: "login_background"),
    "logo" : UIImage(named: "logo"),
    
    
    "clown_icon" : UIImage(named: "clown_icon"),
    "arcadia_top" : UIImage(named: "arcadia_written"),
    "poster1" : UIImage(named: "poster"),
    

]



// MARK: STRINGS


let _strs : [String:String] = [

    "appName" : "Arcadia",
    
    
    "LC_loginLabel" : "Login",
    "LC_userField" : "Username...",
    "LC_passField" : "Password...",
    "LC_recoverField" : "Email...",
    
    "LC_termsLabel" : "Terms and Conditions",
    "LC_privacyLabel" : "Privacy policy",
    
    "LC_downString1" : "Check our ",
    "LC_downString2" : " and ",
    "LC_downString3" : " on the portals",
    
    "SC_search_phd" : "What do you wish... ?"

]



// MARK: CONTROLLERS


var _ctrs : [String:XTController] = [

    "login" : loginController(),
    "fail" : failController(),
    
    "debug" : debugController(),
    "test" : testController(),
    
    "market" : marketController(),
    "profile" : profileController(),
    "map" : mapController(),
    "item" : itemController(),
    
    "history" : historyController(),
    "wallet" : walletController(),
    "chat" : chatController(),
    
    "settings" : settingsController(),
    "create" : createController(),
    

]



// MARK: COLORS

let _clrs : [String:UIColor] = [

    "app_color" : UIColor.red,

    "wallet_color" : UIColor.green,
    
    "witch_glass" : UIColor.black.withAlphaComponent(0.5)
]


// MARK: TAGS


let tags:[String:String] = [

    "background" : "2000",
    "blur" : "2012",
    "logoButton" : "2077",
    "stars" : "1933",
    "bar" : "1851",
    "bar_stack" : "1850",
    "bar_leftItem" : "1847",
    "bar_centerItem" : "1848",
    "bar_rightItem" : "1849",

]
