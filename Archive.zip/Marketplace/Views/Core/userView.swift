//
//  ProfileView.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit


class userView:UIView{
    
    
    var item:user?
    
    
    
    let rS:UIStackView = {
        
        let s = UIStackView()
        s.axis = .vertical
        s.alignment = .center
        s.distribution = .fillProportionally
        s.spacing = 10
        
        
        
        let p = UIImageView(image: core.man.img("clown_icon"))
        
        
        let l = UILabel()
        l.text = "Marco Dumitru"
        l.textColor = .white
        l.textAlignment = .center
        
        
        return s
        
    }()
    
    
    let lS:UIStackView = {
        
        let s = UIStackView()
        
        
        
        return s
        
    }()
    
    
    
    
    
    
    init(_ model: user) {
        super.init(frame: .zero)
    }
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
}
