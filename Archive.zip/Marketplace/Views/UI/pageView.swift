//
//  pageView.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit



class pageView:UIView{
    
    
    let page:UIImageView = {
        
        let p = UIImageView()
        p.contentMode = .scaleAspectFit
        p.image = core.man.img("poster1")
        
        return p
        
    }()
    
    
    
    
    init(_ pages: [UIImage]?) {
        super.init(frame: .zero)
        
        
        
    }
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
