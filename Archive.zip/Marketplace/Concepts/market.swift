//
//  market.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit

struct market{
    
    
    // MARK: PROPS
    
    let id:UUID
    let name:String
    let admin:user
    
    var currency:currency?
    
    var logo:UIImage?
    var tax:Int?
    
    var items:[item]?
    var users:[user]?
    var banned:[user]?
    
    
    let createdBy:UUID?
    let createdAt:Date?
    
    
    
    
    
    // MARK: CURRENCY AND LOGO
    
    
    mutating func setCurrency(_ new: currency){
        
        self.currency = new
        
    }
    
    mutating func setLogo(_ new: UIImage){
        
        self.logo = new
        
    }
    
    
    // MARK: USERS
    
    mutating func banUser(_ users: [user]){
        
        for u in users{
            self.banned?.append(u)
        }
        
    }
    
    mutating func unbanUser(_ users: [user]){
        
        
        for i in 0...users.count - 1{
            for j in 0...self.users!.count - 1{
                if users[i].id == self.users![j].id{
                    self.users!.remove(at: j)
                }
            }
        }
        
        
    }
    
    
    mutating func addUser(_ users: [user]){
        
        for u in users{
            self.users?.append(u)
        }
        
    }
    
    mutating func removeUsers(_ users: [user]){
        
        for i in 0...users.count - 1{
            for j in 0...self.users!.count - 1{
                if users[i].id == self.users?[j].id{
                    self.users?.remove(at: j)
                }
            }
        }
        
        
    }
    
    
    
    // MARK: ITEMS
    
    mutating func addItems(_ items: [item]){
        
        for var i in items{
            i.market = self
            self.items?.append(i)
        }
        
    }
    
    mutating func removeItems(_ items: [item]){
        
        for i in 0...items.count - 1{
            for j in 0...self.items!.count - 1{
                if items[i].id == self.items![j].id{
                    
                    self.items![j].market = nil
                    self.items!.remove(at: j)
                    
                }
            }
        }
        
    }
    
    
    mutating func transferTo(_ items: [item],_ user: user){
        
        
    }
    
    
    // MARK: INTEGRITY
    
    
    mutating func integrity(){
        
        if var uu = self.users{
            if let bb = self.banned{
                for u in 0...uu.count - 1{
                    for b in 0...bb.count - 1{
                        if uu[u].id == bb[b].id{
                        uu.remove(at: u)
                        self.users = uu
                        }
                    }
                }
            }
        }
        
    }
    
    
    
    // MARK: INIT
    
    
    init(name: String, admin: user) {
        self.id = UUID()
        self.name = name
        self.admin = admin
        self.currency = .none
        self.items = []
        self.users = [admin]
        self.banned = []
        self.createdBy = admin.id
        self.createdAt = Date(timeIntervalSinceNow: 0.0)
    }
    
    
    
}
