//
//  walletController.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit



class walletController:XTController{
    
    var vid:[wallet] = [
    
        wallet("fane", currency: .euro, owner: core.usr, code: "1234"),
        wallet("dorel", currency: .bitcoin, owner: core.usr, code: "1234"),
        wallet("garcel", currency: .bitcoin, owner: core.usr, code: "1234")
        
    ]
    
    
    
    
    let table:UITableView = {
        
        let t = UITableView(frame: .zero, style: .grouped)
        t.separatorStyle = .none
        t.backgroundColor = .clear
        t.backgroundView = UIImageView(image: core.man.img("bkg"))
        
        
        return t
        
    }()
    
    

    
    override func ignition(){
        
        addTableDelegate([table])
        view.addSubview(table)
        table.fillSuperview()
        
        setBackground(image: core.man.img("bkg"), nil)
        
    }
    
    
}





extension walletController:UITableViewDelegate, UITableViewDataSource{
    
    

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vid.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.tag = indexPath.row + 1
        cell.backgroundColor = .clear
        
        let v = walletView(vid[indexPath.row])
        
        cell.addSubview(v)
        v.fillSuperview()
        
        
        return cell
    }
    
    
    
    
    
}
