//
//  testController.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit



class testController:XTController{
    
    
    override func ignition() {
        setBackground(image: core.man.img("bkg"), nil)
    }
    
    override func launch(){
        
        addBar(.test)
        
    }
    
    
}
