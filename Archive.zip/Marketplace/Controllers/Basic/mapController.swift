//
//  mapController.swift
//  Marketplace
//
//  Created by Mihai Moldovan on 30/09/2019.
//  Copyright © 2019 Mihai Moldovan. All rights reserved.
//

import Foundation
import UIKit
import MapKit


class mapController:XTController{
    
    
    let map:MKMapView = {
        
        let m = MKMapView()
        
        
        
        return m
        
    }()
    
    
    
    
    override func ignition() {
        setBackground(image: core.man.img("bkg"), nil)
    }
    

    
    
}







extension mapController:MKMapViewDelegate{
    
    
    
    
}


